# MLHub-UI
UI for Machine Learning hub


## Steps to run MLHub-UI in local
1. clone https://github.ibm.com/ISLOps/MLHub-UI
2. npm install
3. npm run build
4. npm run start
